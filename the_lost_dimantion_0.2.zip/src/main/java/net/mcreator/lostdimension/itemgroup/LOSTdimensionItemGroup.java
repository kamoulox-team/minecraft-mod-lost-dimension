
package net.mcreator.lostdimension.itemgroup;

import net.minecraftforge.api.distmarker.OnlyIn;
import net.minecraftforge.api.distmarker.Dist;

import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemGroup;

import net.mcreator.lostdimension.item.RubySwordItem;
import net.mcreator.lostdimension.LostDimensionModElements;

@LostDimensionModElements.ModElement.Tag
public class LOSTdimensionItemGroup extends LostDimensionModElements.ModElement {
	public LOSTdimensionItemGroup(LostDimensionModElements instance) {
		super(instance, 58);
	}

	@Override
	public void initElements() {
		tab = new ItemGroup("tablos_tdimension") {
			@OnlyIn(Dist.CLIENT)
			@Override
			public ItemStack createIcon() {
				return new ItemStack(RubySwordItem.block, (int) (1));
			}

			@OnlyIn(Dist.CLIENT)
			public boolean hasSearchBar() {
				return true;
			}
		}.setBackgroundImageName("item_search.png");
	}
	public static ItemGroup tab;
}
