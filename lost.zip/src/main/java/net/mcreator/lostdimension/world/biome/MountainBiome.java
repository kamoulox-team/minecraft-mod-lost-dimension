
package net.mcreator.lostdimension.world.biome;

import net.minecraftforge.registries.ObjectHolder;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;

import net.minecraft.world.gen.surfacebuilders.SurfaceBuilderConfig;
import net.minecraft.world.gen.surfacebuilders.SurfaceBuilder;
import net.minecraft.world.biome.DefaultBiomeFeatures;
import net.minecraft.world.biome.Biome;
import net.minecraft.entity.EntityClassification;

import net.mcreator.lostdimension.entity.ZombiEntity;
import net.mcreator.lostdimension.entity.SkeletteEntity;
import net.mcreator.lostdimension.block.LoststoneBlock;
import net.mcreator.lostdimension.LostDimensionModElements;

@LostDimensionModElements.ModElement.Tag
public class MountainBiome extends LostDimensionModElements.ModElement {
	@ObjectHolder("lost_dimension:mountain")
	public static final CustomBiome biome = null;
	public MountainBiome(LostDimensionModElements instance) {
		super(instance, 29);
	}

	@Override
	public void initElements() {
		elements.biomes.add(() -> new CustomBiome());
	}

	@Override
	public void init(FMLCommonSetupEvent event) {
	}
	static class CustomBiome extends Biome {
		public CustomBiome() {
			super(new Biome.Builder().downfall(0.5f).depth(2f).scale(0.1f).temperature(0.5f).precipitation(Biome.RainType.RAIN)
					.category(Biome.Category.NONE).waterColor(4159204).waterFogColor(329011)
					.surfaceBuilder(SurfaceBuilder.DEFAULT, new SurfaceBuilderConfig(LoststoneBlock.block.getDefaultState(),
							LoststoneBlock.block.getDefaultState(), LoststoneBlock.block.getDefaultState())));
			setRegistryName("mountain");
			DefaultBiomeFeatures.addCarvers(this);
			DefaultBiomeFeatures.addStructures(this);
			DefaultBiomeFeatures.addMonsterRooms(this);
			DefaultBiomeFeatures.addOres(this);
			DefaultBiomeFeatures.addLakes(this);
			this.addSpawn(EntityClassification.MONSTER, new Biome.SpawnListEntry(ZombiEntity.entity, 20, 4, 4));
			this.addSpawn(EntityClassification.MONSTER, new Biome.SpawnListEntry(SkeletteEntity.entity, 20, 4, 4));
		}
	}
}
