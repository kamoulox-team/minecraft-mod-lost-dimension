
package net.mcreator.lostdimension.item;

import net.minecraftforge.registries.ObjectHolder;

import net.minecraft.item.crafting.Ingredient;
import net.minecraft.item.PickaxeItem;
import net.minecraft.item.Item;
import net.minecraft.item.IItemTier;

import net.mcreator.lostdimension.itemgroup.LOSTdimensionItemGroup;
import net.mcreator.lostdimension.LostDimensionModElements;

@LostDimensionModElements.ModElement.Tag
public class RubyPickaxeItem extends LostDimensionModElements.ModElement {
	@ObjectHolder("lost_dimension:ruby_pickaxe")
	public static final Item block = null;
	public RubyPickaxeItem(LostDimensionModElements instance) {
		super(instance, 18);
	}

	@Override
	public void initElements() {
		elements.items.add(() -> new PickaxeItem(new IItemTier() {
			public int getMaxUses() {
				return 250;
			}

			public float getEfficiency() {
				return 6f;
			}

			public float getAttackDamage() {
				return 0f;
			}

			public int getHarvestLevel() {
				return 2;
			}

			public int getEnchantability() {
				return 14;
			}

			public Ingredient getRepairMaterial() {
				return Ingredient.EMPTY;
			}
		}, 1, -3f, new Item.Properties().group(LOSTdimensionItemGroup.tab)) {
		}.setRegistryName("ruby_pickaxe"));
	}
}
